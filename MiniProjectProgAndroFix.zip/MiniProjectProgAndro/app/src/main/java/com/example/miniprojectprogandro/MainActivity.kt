package com.example.miniprojectprogandro
import android.app.DatePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*
import android.widget.RadioGroup
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : AppCompatActivity() {

    private lateinit var tvDatePicker: TextView
    private lateinit var btnDatePicker: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nextBt = findViewById<Button>(R.id.nextke2)

        nextBt.setOnClickListener {
            callActivity()
        }

        tvDatePicker = findViewById(R.id.tvDate)
        btnDatePicker = findViewById(R.id.InputDate)

        val myCalendar = Calendar.getInstance()

        val datePicker = DatePickerDialog.OnDateSetListener{ view, year, month, dayOfMonth ->
            myCalendar.set(Calendar.YEAR,year)
            myCalendar.set(Calendar.MONTH,month)
            myCalendar.set(Calendar.DAY_OF_MONTH,dayOfMonth)
            updateLable(myCalendar)
        }

        btnDatePicker.setOnClickListener {
            DatePickerDialog(this,datePicker,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show()
        }



        radio_group.setOnCheckedChangeListener(
            RadioGroup.OnCheckedChangeListener { group, checkedId ->
                val radio: RadioButton = findViewById(checkedId)
            })

        button.setOnClickListener{

            var id: Int = radio_group.checkedRadioButtonId
            var id2: Int = radio_group2.checkedRadioButtonId

            if (id!=-1 && id2!=-1 && tvDatePicker.text.toString() != "Date" ){
                nextBt.setText("Next Page -->")
                nextBt.visibility = View.VISIBLE

            }else{

                Toast.makeText(applicationContext,"Please Fill All Field",
                    Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun callActivity(){
        var kotaAsal = ""
        var kotaTujuan = ""
        var tanggal = tvDatePicker.text.toString()
        radio_group.setOnCheckedChangeListener(
            RadioGroup.OnCheckedChangeListener { group, checkedId ->
                val radio: RadioButton = findViewById(checkedId)
                kotaAsal = radio.toString()

            })

        radio_group2.setOnCheckedChangeListener(
            RadioGroup.OnCheckedChangeListener { group, checkedId ->
                val radio2: RadioButton = findViewById(checkedId)
                kotaTujuan = radio2.toString()
            })

        val intent = Intent(this,HalamanDua::class.java).also{
            it.putExtra("kotaAsal",kotaAsal)
            it.putExtra("kotaAsal",kotaTujuan)
            it.putExtra("tanggal",tanggal)
            startActivity(it)
        }
    }

    private fun updateLable(myCalendar: Calendar){
        val myFormat = "dd-MM-yyyy"
        val sdf = SimpleDateFormat(myFormat,Locale.UK)
        tvDatePicker.setText(sdf.format(myCalendar.time))

    }
    // Get the selected radio button text using radio button on click listener
    fun radio_button_click(view: View){
        // Get the clicked radio button instance
        val radio: RadioButton = findViewById(radio_group.checkedRadioButtonId)
        Toast.makeText(applicationContext,"On click : ${radio.text}",
            Toast.LENGTH_SHORT).show()
    }
}