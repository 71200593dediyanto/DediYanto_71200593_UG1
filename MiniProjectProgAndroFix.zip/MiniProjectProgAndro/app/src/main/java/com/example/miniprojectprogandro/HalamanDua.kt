package com.example.miniprojectprogandro

import android.app.DatePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*
import android.widget.RadioGroup
import kotlinx.android.synthetic.main.halamandua.*
import java.text.SimpleDateFormat
import java.util.*

class HalamanDua : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.halamandua)

        val nextBt = findViewById<Button>(R.id.nextke3)
        val kotaAsal = intent.getStringExtra("kotaAsal")
        val kotaTujuan = intent.getStringExtra("KotTujuan")
        val tanggal = intent.getStringExtra("tanggal")

        nextBt.setOnClickListener {
            val intent = Intent(this,HalamanDua::class.java).also{
                it.putExtra("kotaAsal",kotaAsal)
                it.putExtra("kotaAsal",kotaTujuan)
                it.putExtra("tanggal",tanggal)
                startActivity(it)}
        }

        radio_group_waktu.setOnCheckedChangeListener(
            RadioGroup.OnCheckedChangeListener { group, checkedId ->
                val radio: RadioButton = findViewById(checkedId)
            })

            radio_group_kelas.setOnCheckedChangeListener(
                RadioGroup.OnCheckedChangeListener { group, checkedId ->
                    val radio: RadioButton = findViewById(checkedId)
                })

        button2.setOnClickListener{

            var id: Int = radio_group_waktu.checkedRadioButtonId
            var id2: Int = radio_group_kelas.checkedRadioButtonId
            if (id!=-1 && id2 !=-1 ){
                val radio: RadioButton = findViewById(id)
                nextBt.setText("Next Page -->")
                nextBt.visibility = View.VISIBLE
            }else{

                Toast.makeText(applicationContext,"On button click :" +
                        " nothing selected",
                    Toast.LENGTH_SHORT).show()
            }
        }
    }


    fun radio_button_click(view: View){
        // Get the clicked radio button instance
        val radio: RadioButton = findViewById(radio_group.checkedRadioButtonId)
        Toast.makeText(applicationContext,"On click : ${radio.text}",
            Toast.LENGTH_SHORT).show()
    }

}